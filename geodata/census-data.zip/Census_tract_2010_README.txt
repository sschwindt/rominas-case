Census Tract 2010 - Census of Population and Housing

PRIVATE HOUSING
Toponimio_ID = tract ID
Varon = number of Man
Mujer = number of Woman 
TotalPob= Total population
Hogares = tota number of houses
Vivienda_SP= Total private housing
Viv_part_H =inhabited houses


Data source = http://geosplan.tucuman.gov.ar/index.php/geoservicios/descargar-datos/
              https://redatam.indec.gob.ar/argbin/RpWebEngine.exe/PortalAction?&MODE=MAIN&BASE=CPV2010B&MAIN=WebServerMain.inl&_ga=2.52887272.1972302034.1589237672-669091707.1583177789